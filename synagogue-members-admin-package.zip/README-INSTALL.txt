SYNAGOGUE MEMBERS ADMIN — INSTALLATION

Files:
1. members-admin.html
2. members-button.js
3. supabase-members.sql
4. supabase/functions/member-admin/index.ts

STEP 1 — Supabase SQL
Open Supabase -> SQL Editor.
Paste/run the entire contents of supabase-members.sql.

STEP 2 — Edge Function
Create/deploy an Edge Function named:
member-admin

Replace its index.ts with:
supabase/functions/member-admin/index.ts

The function uses Supabase's built-in environment variables:
SUPABASE_URL
SUPABASE_SERVICE_ROLE_KEY
Do NOT put the service-role key in GitHub Pages.

STEP 3 — Add the Rabbi Members button to admin.html
Immediately before </body>, add:

<script src="members-button.js"></script>

This automatically places:
👥 ניהול חברי בית הכנסת
inside your "כפתורי שליטה מיידית" section and also adds a Members navigation button.

STEP 4 — Upload to GitHub Pages
Upload:
members-admin.html
members-button.js

to the same folder as:
admin.html
supabase-config.js
saas-common.js

STEP 5 — Test
Log in as one synagogue Rabbi/admin.
Open admin.html.
Press "👥 ניהול חברי בית הכנסת".

The page identifies the logged-in Rabbi by Supabase Auth and uses synagogues.owner_user_id.
A Rabbi can only manage members belonging to that Rabbi's synagogue.
A master user can open:
members-admin.html?s=SYNAGOGUE_UUID

SECURITY
Existing passwords can never be displayed. Supabase Auth stores password hashes, not readable passwords.
The Rabbi can set a NEW temporary password through the secure Edge Function.

SUPPORTED ACTIONS
- View member list and all stored profile information
- Search
- Add member/login
- Approve
- Suspend / reactivate
- Edit
- Set a new temporary password
- Delete

IMPORTANT
Your existing admin.html code does not need to be rewritten. The one members-button.js include adds the new button without interfering with the prayer/settings code.
